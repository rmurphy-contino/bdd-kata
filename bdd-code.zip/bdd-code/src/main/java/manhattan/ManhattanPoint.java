package manhattan;

public class ManhattanPoint {
	public int gridSize = 20;
	public int posX = 0;
	public int posY = 0;

	public ManhattanPoint(int x, int y) {
		posX = x;
		posY = y;
		gridSize = 20;
	}

	public ManhattanPoint(int x, int y, int size) {
		posX = x;
		posY = y;
		gridSize = size;
	}
}
