package bdd;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StepDefinitions {

    private Area area;

    @Given("a square")
	public void a_shape() {
	    area = new Area("square");
	}

	@When("the sides are {int} ft")
	public void the_sides_are_ft(Integer sides) {
	    area.dimensions.add(sides);
	}

	@Then("the area is {double} sqft")
	public void the_area_is_dbl_sqft(Double amount) {
	    assertEquals(amount, area.calculate());
	}
}

