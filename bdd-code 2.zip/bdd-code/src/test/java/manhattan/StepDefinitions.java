package manhattan;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StepDefinitions {

    private int gridSize;
	private ManhattanPoint firstPoint;
	private ManhattanPoint secondPoint;

    @Given("a grid size of {int}")
    public void givenFirstPoint(int size) {
        int gridSize = size;
    }

    @When("a point with position {int}, {int}")
    public void whenFirstPoint(int x, int y) {
        firstPoint = new ManhattanPoint(x, y, gridSize);
    }

    @And("another point with position {int}, {int}")
    public void andSecondPoint(int x, int y) {
        secondPoint = new ManhattanPoint(x, y, gridSize);
    }

    @Then("the distance between them is {double}")
    public void thenCalculateDistance(double distance) {
        ManhattanDistance tool = new ManhattanDistance();
        assertEquals(tool.calculate(firstPoint, secondPoint), distance);
    }
}