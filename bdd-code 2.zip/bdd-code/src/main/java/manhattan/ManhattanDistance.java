package manhattan;

import java.lang.*;

public class ManhattanDistance {
	public int calculate(ManhattanPoint firstPoint, ManhattanPoint secondPoint) {
		int xDistance = Math.abs(firstPoint.posX - secondPoint.posX);
		int yDistance = Math.abs(firstPoint.posY - secondPoint.posY);

		return (int) Math.hypot(xDistance, yDistance);
	}
}