package bdd;

import java.util.ArrayList;

public class Area {
	public ArrayList<Integer> dimensions = new ArrayList<Integer>();
	public String shape;

	public Area(String inputShape) {
		shape = inputShape;
	}

	public Double calculate() {
		switch(shape) {
			case "square":
				return Math.pow(dimensions.get(0), 2);
			case "rectangle":
				return (double) dimensions.get(1) * dimensions.get(0);
			case "triangle":
				return (double) (0.5*dimensions.get(0)) * dimensions.get(1);
			default:
				return 0.0;
		}
	}
}